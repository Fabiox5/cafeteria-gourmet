// backend/seed.js
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const Product = require('./models/Product');

dotenv.config();

const sampleProducts = [
  { name: "Camisa Branca", price: 59.90, description: "Camisa branca 100% algodão", image: "" },
  { name: "Calça Jeans", price: 120.00, description: "Calça jeans azul escura", image: "" },
  { name: "Tênis Esportivo", price: 250.50, description: "Tênis confortável para corrida", image: "" }
];

const seedDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("MongoDB conectado");

    await Product.deleteMany({});
    await Product.insertMany(sampleProducts);

    console.log("Produtos de exemplo inseridos com sucesso!");
    process.exit();
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
};

seedDB();
